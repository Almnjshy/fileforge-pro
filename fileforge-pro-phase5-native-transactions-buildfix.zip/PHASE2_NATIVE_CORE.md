# FileForge Pro — Phase 2 Native Core

## Objective
Make the native storage core a real provider architecture rather than a facade
that branches on strings. Local filesystem paths and Android SAF references
must be first-class, strongly separated resources with one stable application
contract.

## Implemented

### 1. Typed storage references
`StorageReference` now distinguishes:
- `Local(File)` for absolute filesystem paths.
- `Saf(Uri)` for validated `content://` references.

The conversion happens once at the native boundary. A SAF URI can no longer be
accidentally coerced into `java.io.File` by the storage core.

### 2. Provider contract
`StorageProvider` is now reference-based and exposes the common storage
operations:
- metadata/list
- create file/directory
- delete/rename
- streaming input/output
- bounded text reads/writes
- bounded random/chunk reads/writes

### 3. Concrete providers
- `DirectStorageProvider` owns local filesystem mechanics.
- `SafStorageProvider` owns DocumentFile/ContentResolver mechanics.
- `UnifiedStorageService` is now orchestration only.

### 4. SAF directory correctness
SAF child directory references are resolved through both tree and single-document
forms. This removes a common failure where listing worked only for the selected
root but failed after entering a nested SAF directory.

### 5. Atomic staging remains provider-aware
Chunked writes require target and staging references to belong to the same
provider. Local and SAF transactions cannot accidentally be mixed.

### 6. Validation
Both providers enforce child-name rules and reject path separators, NUL,
`.` and `..`. Local creation also verifies canonical parent identity.

## Architecture after Phase 2

`React/TypeScript`
        -> `Capacitor adapter`
        -> `UnifiedStorageService`
        -> `StorageReference`
        -> `StorageProvider`
        -> `DirectStorageProvider | SafStorageProvider`
        -> `Android filesystem | SAF`

The adapter is not responsible for choosing `File` vs `content://` semantics.

## Explicitly not claimed
- Full background-job execution across Android process death.
- True resume for arbitrary SAF providers.
- Remote/cloud providers.
- Device-level compatibility verification for every OEM SAF provider.

Those are separate engineering problems and are not hidden behind fallback code.

## Phase 2 acceptance gate
Before merging this phase, CI/device verification must confirm:
1. TypeScript typecheck passes.
2. Static Next build passes.
3. Android compile passes.
4. Local CRUD works.
5. SAF root CRUD works.
6. Nested SAF directory listing/create/rename/delete works.
7. Local and SAF references cannot be mixed in a chunked transaction.
8. Chunk reads remain bounded and do not materialize entire files.
9. Existing Capacitor method names and response fields remain compatible.
