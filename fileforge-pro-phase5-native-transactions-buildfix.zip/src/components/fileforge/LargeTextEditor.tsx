"use client";

import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Save, Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getNode, getExt } from "@/lib/fileforge/filesystem";
import { fileRepository } from "@/lib/fileforge/file-repository";
import { LargeDocumentEngine } from "@/lib/fileforge/large-document-engine";
import { formatBytes } from "@/lib/fileforge/filesystem";

const LANG: Record<string,string>={txt:"text",log:"text",md:"markdown",json:"json",js:"javascript",ts:"typescript",tsx:"typescript",jsx:"javascript",py:"python",kt:"kotlin",java:"java",rs:"rust",go:"go",html:"html",htm:"html",css:"css",xml:"xml",yaml:"yaml",yml:"yaml"};

export function LargeTextEditor({ nodeId }: { nodeId:string; winId:string }) {
  const node=getNode(nodeId);
  const [engine,setEngine]=useState<LargeDocumentEngine|null>(null);
  const [page,setPage]=useState(0);
  const [text,setText]=useState("");
  const [loading,setLoading]=useState(true);
  const [saving,setSaving]=useState(false);
  const [dirty,setDirty]=useState(false);
  const [error,setError]=useState<string|null>(null);
  const [query,setQuery]=useState("");
  const [match,setMatch]=useState<number|null>(null);

  useEffect(()=>{
    let cancelled=false;
    (async()=>{
      try{
        setLoading(true); setError(null);
        const meta=await fileRepository.getMetadata(nodeId);
        if(!meta) throw new Error("File metadata unavailable");
        const e=new LargeDocumentEngine(nodeId,meta.size);
        const t=await e.getPageText(0);
        if(cancelled)return;
        setEngine(e); setText(t); setPage(0); setDirty(false);
      }catch(e:any){ if(!cancelled)setError(e?.message??"Unable to open large document"); }
      finally{ if(!cancelled)setLoading(false); }
    })();
    return()=>{cancelled=true};
  },[nodeId]);

  const pageCount=engine?.pageCount??0;
  const ext=node?getExt(node.name):"";
  const lang=LANG[ext]??"text";
  const lines=useMemo(()=>text.split("\n"),[text]);

  async function go(next:number){
    if(!engine || next<0 || next>=engine.pageCount || next===page)return;
    if(dirty){
      setError("Save the current page before changing pages.");
      return;
    }
    setLoading(true); setError(null);
    try{ setText(await engine.getPageText(next)); setPage(next); setMatch(null); }
    catch(e:any){setError(e?.message??"Unable to load page");}
    finally{setLoading(false);}
  }

  async function save(){
    if(!engine)return;
    try{
      setSaving(true); setError(null);
      await engine.updatePage(page,text);
      await engine.save();
      setDirty(false);
    }catch(e:any){setError(e?.message??"Unable to save document");}
    finally{setSaving(false);}
  }

  function find(){ if(!query){setMatch(null);return;} const i=text.toLocaleLowerCase().indexOf(query.toLocaleLowerCase()); setMatch(i>=0?i:null); }

  if(loading && !engine)return <div className="flex h-full items-center justify-center text-sm text-muted-foreground">Loading large document…</div>;
  if(error && !engine)return <div className="p-4 text-sm text-destructive">{error}</div>;

  return <div className="flex h-full min-h-0 flex-col bg-background font-mono text-sm">
    <div className="flex items-center gap-2 border-b px-2 py-1.5">
      <span className="truncate text-xs text-muted-foreground">Paged editor · {formatBytes(engine?.fileSize??0)}</span>
      <div className="flex-1" />
      <Input value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")find()}} placeholder="Find in page" className="h-7 w-36 text-xs" />
      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={find}><Search className="h-3.5 w-3.5"/></Button>
      <Button size="sm" className="h-7" onClick={save} disabled={!dirty||saving}><Save className="mr-1 h-3.5 w-3.5"/>{saving?"Saving…":"Save"}</Button>
    </div>
    {error&&<div className="flex items-center gap-2 border-b px-3 py-1 text-xs text-destructive"><span className="flex-1">{error}</span><Button variant="ghost" size="icon" className="h-6 w-6" onClick={()=>setError(null)}><X className="h-3 w-3"/></Button></div>}
    <div className="flex-1 min-h-0 overflow-auto">
      <textarea value={text} onChange={e=>{setText(e.target.value);setDirty(true)}} spellCheck={false} className="min-h-full w-full resize-none border-0 bg-transparent p-3 leading-5 outline-none" aria-label="Large text editor page" />
    </div>
    <div className="flex items-center gap-2 border-t px-2 py-1 text-[10px] text-muted-foreground">
      <Button variant="ghost" size="icon" className="h-6 w-6" disabled={page<=0||dirty} onClick={()=>go(page-1)}><ChevronLeft className="h-3.5 w-3.5"/></Button>
      <span>Page {page+1} / {pageCount||1}</span>
      <Button variant="ghost" size="icon" className="h-6 w-6" disabled={page>=pageCount-1||dirty} onClick={()=>go(page+1)}><ChevronRight className="h-3.5 w-3.5"/></Button>
      <span>·</span><span>{lines.length.toLocaleString()} lines</span><span>·</span><span>{text.length.toLocaleString()} chars loaded</span>
      <span>·</span><span>UTF-8</span><span>·</span><span>{lang}</span>
      {match!==null&&<span className="ml-auto">Match at {match.toLocaleString()}</span>}
      {dirty&&<span className="ml-auto text-orange-500">Modified</span>}
    </div>
  </div>;
}
