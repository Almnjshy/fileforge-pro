// FileForge Pro — Text Editor with syntax highlighting
"use client";

import { useState, useEffect, useMemo, useRef } from "react";
import {
  Save, FileDown, Search, Replace, Undo, Redo, FileText, Eye, Code, X,
} from "lucide-react";
import { useFileForge } from "@/store/fileforge-store";
import { getNode, formatBytes } from "@/lib/fileforge/filesystem";
import { nativeFileSystem, isNative } from "@/lib/fileforge/native-bridge";
import { fileRepository } from "@/lib/fileforge/file-repository";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { getExt } from "@/lib/fileforge/filesystem";

const EXT_LANG: Record<string, string> = {
  js: "javascript", jsx: "javascript", ts: "typescript", tsx: "typescript",
  py: "python", java: "java", kt: "kotlin", kts: "kotlin",
  go: "go", rs: "rust", c: "c", cpp: "cpp", h: "c",
  sh: "bash", bash: "bash", sql: "sql",
  json: "json", yaml: "yaml", yml: "yaml", toml: "toml",
  xml: "xml", html: "html", htm: "html", css: "css", scss: "scss",
  md: "markdown", txt: "text", log: "text", conf: "ini", ini: "ini",
  csv: "csv",
};

// Very lightweight syntax highlighting using regex per language
function highlight(code: string, lang: string): { text: string; cls: string }[][] {
  const lines = code.split("\n");
  return lines.map(line => highlightLine(line, lang));
}

function highlightLine(line: string, lang: string): { text: string; cls: string }[] {
  // Simple tokenizer — produce runs of styled text
  const tokens: { text: string; cls: string }[] = [];
  const push = (text: string, cls = "") => {
    if (text) tokens.push({ text, cls });
  };

  // Comments
  const commentMatch = line.match(/^(\s*)(#.*)$/);
  if (lang === "python" || lang === "bash" || lang === "yaml" || lang === "toml") {
    if (commentMatch) {
      push(commentMatch[1]);
      push(commentMatch[2], "text-muted-foreground italic");
      return tokens;
    }
  }
  const slashMatch = line.match(/^(\s*)(\/\/.*)$/);
  if (["javascript", "typescript", "c", "cpp", "java", "go", "rust", "css", "scss"].includes(lang)) {
    if (slashMatch) {
      push(slashMatch[1]);
      push(slashMatch[2], "text-muted-foreground italic");
      return tokens;
    }
  }
  if (lang === "sql") {
    const m = line.match(/^(\s*)(--.*)$/);
    if (m) {
      push(m[1]);
      push(m[2], "text-muted-foreground italic");
      return tokens;
    }
  }

  // HTML/XML tags
  if (lang === "html" || lang === "xml") {
    const regex = /(<\/?[a-zA-Z][^>]*>)/g;
    let last = 0;
    let m;
    while ((m = regex.exec(line)) !== null) {
      if (m.index > last) push(line.slice(last, m.index));
      push(m[0], "text-pink-600 dark:text-pink-400");
      last = m.index + m[0].length;
    }
    if (last < line.length) push(line.slice(last));
    return tokens.length ? tokens : [{ text: line, cls: "" }];
  }

  // String literals (single/double/backtick)
  const strRegex = /(["'`])(?:\\.|(?!\1).)*\1/g;
  let last = 0;
  let m;
  while ((m = strRegex.exec(line)) !== null) {
    if (m.index > last) {
      // Process keywords in the gap
      processKeywords(line.slice(last, m.index), push, lang);
    }
    push(m[0], "text-emerald-600 dark:text-emerald-400");
    last = m.index + m[0].length;
  }
  if (last < line.length) processKeywords(line.slice(last), push, lang);

  if (tokens.length === 0) push(line);
  return tokens;
}

function processKeywords(text: string, push: (s: string, cls?: string) => void, lang: string) {
  const KEYWORDS: Record<string, string[]> = {
    javascript: ["const", "let", "var", "function", "return", "if", "else", "for", "while", "class", "new", "import", "export", "from", "default", "async", "await", "try", "catch", "throw", "typeof", "instanceof", "this", "null", "undefined", "true", "false"],
    typescript: ["const", "let", "var", "function", "return", "if", "else", "for", "while", "class", "new", "import", "export", "from", "default", "async", "await", "try", "catch", "throw", "typeof", "instanceof", "this", "null", "undefined", "true", "false", "interface", "type", "enum", "extends", "implements", "public", "private", "protected", "readonly", "static"],
    python: ["def", "class", "import", "from", "as", "if", "elif", "else", "for", "while", "try", "except", "finally", "return", "yield", "raise", "with", "lambda", "pass", "break", "continue", "in", "is", "not", "and", "or", "None", "True", "False", "self", "global", "nonlocal"],
    java: ["public", "private", "protected", "class", "interface", "extends", "implements", "static", "final", "void", "int", "long", "double", "float", "boolean", "char", "String", "if", "else", "for", "while", "do", "switch", "case", "break", "continue", "return", "new", "try", "catch", "finally", "throw", "throws", "import", "package", "this", "super", "null", "true", "false"],
    go: ["package", "import", "func", "var", "const", "type", "struct", "interface", "if", "else", "for", "switch", "case", "default", "break", "continue", "return", "go", "defer", "chan", "map", "range", "make", "new", "nil", "true", "false"],
    rust: ["fn", "let", "mut", "const", "static", "struct", "enum", "trait", "impl", "pub", "private", "if", "else", "for", "while", "loop", "match", "return", "break", "continue", "use", "mod", "crate", "self", "super", "as", "ref", "move", "async", "await", "unsafe"],
    sql: ["SELECT", "FROM", "WHERE", "INSERT", "UPDATE", "DELETE", "CREATE", "DROP", "ALTER", "TABLE", "INDEX", "VIEW", "INTO", "VALUES", "SET", "JOIN", "LEFT", "RIGHT", "INNER", "OUTER", "ON", "GROUP", "BY", "ORDER", "HAVING", "LIMIT", "OFFSET", "AS", "AND", "OR", "NOT", "NULL", "PRIMARY", "KEY", "FOREIGN", "REFERENCES", "DEFAULT", "UNIQUE", "CASCADE"],
    bash: ["if", "then", "else", "elif", "fi", "for", "in", "do", "done", "while", "case", "esac", "function", "return", "exit", "echo", "export", "local", "readonly", "source", "alias"],
    css: ["color", "background", "border", "margin", "padding", "display", "position", "top", "left", "right", "bottom", "width", "height", "font", "text", "align", "justify", "flex", "grid", "gap", "cursor", "transition", "transform", "animation"],
  };

  const keywords = KEYWORDS[lang] ?? [];
  // Number literals
  const regex = /(\b\d+(?:\.\d+)?\b)|([a-zA-Z_$][a-zA-Z0-9_$]*)|(\s+)|([^\w\s])/g;
  let m;
  while ((m = regex.exec(text)) !== null) {
    if (m[1]) push(m[1], "text-amber-600 dark:text-amber-400");
    else if (m[2]) {
      if (keywords.includes(m[2])) push(m[2], "text-purple-600 dark:text-purple-400 font-medium");
      else if (m[2][0] === m[2][0].toUpperCase() && m[2] !== m[2].toLowerCase()) push(m[2], "text-sky-600 dark:text-sky-400");
      else push(m[2]);
    }
    else if (m[3]) push(m[3]);
    else if (m[4]) {
      // Operators
      if ("+-*/=<>!&|".includes(m[4])) push(m[4], "text-pink-600 dark:text-pink-400");
      else push(m[4]);
    }
  }
}

export function TextEditor({ nodeId, winId }: { nodeId: string; winId: string }) {
  const store = useFileForge();
  const node = getNode(nodeId);
  const ext = node ? getExt(node.name) : "";
  const lang = EXT_LANG[ext] ?? "text";

  const [content, setContent] = useState(node?.content ?? "");
  const [originalContent, setOriginalContent] = useState(node?.content ?? "");
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [replaceQuery, setReplaceQuery] = useState("");
  const [readOnly, setReadOnly] = useState(false);
  const [showLineNumbers, setShowLineNumbers] = useState(true);
  const [showPreview, setShowPreview] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });
  const [history, setHistory] = useState<string[]>([content]);
  const [historyIdx, setHistoryIdx] = useState(0);
  const lastPushRef = useRef<number>(0);

  const dirty = content !== originalContent;

  // Load real file content from native filesystem
  useEffect(() => {
    if (!node) return;
    let cancelled = false;
    async function loadContent() {
      setLoading(true);
      setError(null);
      try {
        // Large file guard — refuse to load files > 5MB as text to avoid OOM
        if (isNative() && node!.id.startsWith("/")) {
          try {
            const meta = await fileRepository.getMetadata(node!.id);
            if (meta && meta.size > 5_000_000) {
              if (!cancelled) {
                setError(`File is too large (${formatBytes(meta.size)}) to open as text. Use "Open Externally" instead.`);
                setReadOnly(true);
              }
              setLoading(false);
              return;
            }
          } catch { /* metadata fetch failed — proceed anyway */ }
        }
        // In native app, read real file
        if (isNative()) {
          const realContent = await nativeFileSystem.readText(node!.id);
          if (!cancelled && realContent !== null) {
            setContent(realContent);
            setOriginalContent(realContent);
          }
        }
        // In web preview, use mock content from node
      } catch (e: any) {
        if (!cancelled) {
          setError(e?.message || "Failed to read file");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    loadContent();
    return () => { cancelled = true; };
  }, [node?.id]);

  const highlightedLines = useMemo(() => highlight(content, lang), [content, lang]);

  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    const updateCursor = () => {
      const pos = ta.selectionStart;
      const before = content.slice(0, pos);
      const lines = before.split("\n");
      setCursorPos({ line: lines.length, col: lines[lines.length - 1].length + 1 });
    };
    ta.addEventListener("keyup", updateCursor);
    ta.addEventListener("click", updateCursor);
    return () => {
      ta.removeEventListener("keyup", updateCursor);
      ta.removeEventListener("click", updateCursor);
    };
  }, [content]);

  const handleChange = (v: string) => {
    if (readOnly) return;
    setContent(v);
    // Debounce history pushes: only snapshot when ≥500ms have elapsed since
    // the last push OR when the change is large (>200 chars). Previously the
    // history array was rebuilt on every keystroke, making undo mostly
    // useless (one entry per character) and triggering an O(n) copy of a
    // 50-entry array per type.
    const now = Date.now();
    const diff = Math.abs(v.length - content.length);
    if (now - lastPushRef.current < 500 && diff < 200) return;
    lastPushRef.current = now;
    const newHist = history.slice(0, historyIdx + 1);
    newHist.push(v);
    if (newHist.length > 50) newHist.shift();
    setHistory(newHist);
    setHistoryIdx(newHist.length - 1);
  };

  const undo = () => {
    if (historyIdx > 0) {
      setHistoryIdx(historyIdx - 1);
      setContent(history[historyIdx - 1]);
    }
  };
  const redo = () => {
    if (historyIdx < history.length - 1) {
      setHistoryIdx(historyIdx + 1);
      setContent(history[historyIdx + 1]);
    }
  };

  const save = async () => {
    if (!node) return;
    setSaving(true);
    setError(null);
    try {
      // In native app, write to real file
      if (isNative()) {
        const success = await nativeFileSystem.writeText(node.id, content);
        if (!success) {
          throw new Error("Failed to write file");
        }
      }
      // Also update mock state
      store.saveFileContent(node.id, content);
      setOriginalContent(content);
      store.addToast("File saved", "success");
    } catch (e: any) {
      setError(e?.message || "Failed to save file");
      store.addToast("Failed to save file", "error");
    } finally {
      setSaving(false);
    }
  };

  const replaceAll = () => {
    if (searchQuery) {
      handleChange(content.split(searchQuery).join(replaceQuery));
    }
  };

  const saveAs = () => {
    if (!node) return;
    // Build a Blob from the current content and trigger a real download
    // via a hidden <a download> element (was a toast placeholder).
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = node.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    store.addToast("File downloaded", "success");
  };

  if (!node) return <div className="p-4">File not found</div>;

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center gap-1 px-2 h-9 border-b bg-muted/30 flex-shrink-0">
        <Button variant="ghost" size="sm" className="h-7 gap-1.5" disabled={!dirty} onClick={save}>
          <Save className="h-3.5 w-3.5" /> <span className="text-xs">Save</span>
          {dirty && <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />}
        </Button>
        <Button variant="ghost" size="sm" className="h-7" onClick={saveAs} title="Save As">
          <FileDown className="h-3.5 w-3.5" />
        </Button>
        <div className="h-5 w-px bg-border mx-1" />
        <Button variant="ghost" size="sm" className="h-7" disabled={historyIdx <= 0} onClick={undo}>
          <Undo className="h-3.5 w-3.5" />
        </Button>
        <Button variant="ghost" size="sm" className="h-7" disabled={historyIdx >= history.length - 1} onClick={redo}>
          <Redo className="h-3.5 w-3.5" />
        </Button>
        <div className="h-5 w-px bg-border mx-1" />
        <Button variant="ghost" size="sm" className="h-7" onClick={() => setSearchOpen(!searchOpen)}>
          <Search className="h-3.5 w-3.5" />
        </Button>
        <div className="flex-1" />
        <Button variant="ghost" size="sm" className="h-7"
          onClick={() => setReadOnly(!readOnly)}
          title={readOnly ? "Read-only" : "Editable"}
        >
          {readOnly ? <Eye className="h-3.5 w-3.5 text-orange-500" /> : <Code className="h-3.5 w-3.5" />}
        </Button>
        <Button variant="ghost" size="sm" className="h-7" onClick={() => setShowLineNumbers(!showLineNumbers)}>
          <FileText className="h-3.5 w-3.5" />
        </Button>
        <Badge variant="outline" className="text-[10px] uppercase">{lang}</Badge>
      </div>

      {/* Search bar */}
      {searchOpen && (
        <div className="flex items-center gap-1 px-2 py-1.5 border-b bg-muted/20">
          <Input
            placeholder="Find..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-7 text-xs flex-1"
          />
          <Input
            placeholder="Replace..."
            value={replaceQuery}
            onChange={(e) => setReplaceQuery(e.target.value)}
            className="h-7 text-xs flex-1"
          />
          <Button variant="ghost" size="sm" className="h-7" onClick={replaceAll}>
            <Replace className="h-3.5 w-3.5" /> All
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setSearchOpen(false)}>
            <X className="h-3.5 w-3.5" />
          </Button>
        </div>
      )}

      {/* Editor */}
      <div className="flex-1 min-h-0 relative overflow-hidden font-mono text-sm bg-background">
        <div className="absolute inset-0 flex">
          {/* Line numbers */}
          {showLineNumbers && (
            <div className="flex-shrink-0 py-2 px-2 text-right text-muted-foreground/50 text-xs select-none bg-muted/20 border-r overflow-hidden">
              {highlightedLines.map((_, i) => (
                <div key={i} className="leading-5">{i + 1}</div>
              ))}
            </div>
          )}
          {/* Highlight overlay */}
          <div className="flex-1 relative overflow-auto">
            <pre
              className="absolute inset-0 p-2 leading-5 pointer-events-none whitespace-pre-wrap break-words"
              aria-hidden
            >
              {highlightedLines.map((line, i) => (
                <div key={i} className="leading-5 min-h-5">
                  {line.map((tok, j) => (
                    <span key={j} className={tok.cls}>{tok.text}</span>
                  ))}
                  {line.length === 0 && "\u00a0"}
                </div>
              ))}
            </pre>
            {/* Textarea — text-transparent so the highlighted <pre> underneath shows
                through, but selection needs an explicit ::selection style to be
                visible (otherwise the highlight is invisible on transparent text). */}
            <textarea
              ref={textareaRef}
              value={content}
              onChange={(e) => handleChange(e.target.value)}
              readOnly={readOnly}
              spellCheck={false}
              className="absolute inset-0 w-full h-full p-2 leading-5 bg-transparent text-transparent caret-foreground resize-none outline-none whitespace-pre-wrap break-words ff-textarea-selectable"
              style={{ caretColor: "currentColor" }}
            />
          </div>
        </div>
      </div>

      {/* Status bar */}
      <div className="flex items-center gap-3 px-3 h-6 border-t bg-muted/20 text-[10px] text-muted-foreground flex-shrink-0">
        <style>{`textarea.ff-textarea-selectable::selection { background: rgba(249, 115, 22, 0.4); color: transparent; }`}</style>
        <span>Ln {cursorPos.line}, Col {cursorPos.col}</span>
        <span>·</span>
        <span>{content.length} chars</span>
        <span>·</span>
        <span>{content.split("\n").length} lines</span>
        <span>·</span>
        <span>UTF-8</span>
        <div className="flex-1" />
        {dirty && <span className="text-orange-500 font-medium">Modified</span>}
        {readOnly && <span className="text-orange-500">Read Only</span>}
      </div>
    </div>
  );
}
