// FileForge Pro — Secure Vault Panel
"use client";

import { useState } from "react";
import { useFileForge } from "@/store/fileforge-store";
import { useI18n } from "@/lib/i18n/i18n-store";
import { SecureVault, type VaultEntry } from "@/lib/fileforge/secure-vault";
import { Lock, Unlock, Plus, Trash2, Eye, EyeOff, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export function SecureVaultPanel() {
  const store = useFileForge();
  const { t } = useI18n();
  const [pin, setPin] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [error, setError] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [entries, setEntries] = useState<VaultEntry[]>([]);
  const [newName, setNewName] = useState("");
  const [newContent, setNewContent] = useState("");

  const handleSetPin = async () => {
    if (pin.length < 4) {
      setError("PIN must be at least 4 digits");
      return;
    }
    await SecureVault.setPin(pin);
    setUnlocked(true);
    setEntries(SecureVault.getEntries());
    setError("");
  };

  const handleUnlock = async () => {
    try {
      if (await SecureVault.verifyPin(pin)) {
        setUnlocked(true);
        setEntries(SecureVault.getEntries());
        setError("");
      } else {
        const attemptsLeft = Math.max(0, 5 - SecureVault.getFailedAttempts());
        setError(
          attemptsLeft > 0
            ? `Wrong PIN — ${attemptsLeft} attempt${attemptsLeft === 1 ? "" : "s"} left`
            : "Wrong PIN"
        );
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "";
      if (msg.startsWith("VAULT_LOCKED:")) {
        const ms = Number(msg.split(":")[1] ?? 0);
        const seconds = Math.ceil(ms / 1000);
        setError(`Too many attempts. Try again in ${seconds}s.`);
      } else {
        setError("Wrong PIN");
      }
    }
  };

  const handleAdd = async () => {
    if (!newName || !newContent) return;
    const { encryptedData, iv } = await SecureVault.encrypt(newContent, pin);
    await SecureVault.addEntry({
      name: newName,
      kind: "text",
      size: newContent.length,
      encryptedData,
      iv,
    });
    setEntries(SecureVault.getEntries());
    setNewName("");
    setNewContent("");
    store.addToast("Added to vault", "success");
  };

  const handleDecrypt = async (entry: VaultEntry) => {
    try {
      const content = await SecureVault.decrypt(entry.encryptedData, entry.iv, pin);
      alert(`${entry.name}:\n\n${content}`);
    } catch {
      setError("Failed to decrypt");
    }
  };

  const handleRemove = (id: string) => {
    SecureVault.removeEntry(id);
    setEntries(SecureVault.getEntries());
  };

  if (!SecureVault.isPinSet()) {
    return (
      <div className="flex flex-col h-full p-6 gap-4">
        <div className="flex flex-col items-center text-center gap-3 pb-4 border-b">
          <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center text-white shadow-lg">
            <Shield className="h-8 w-8" />
          </div>
          <div>
            <div className="font-semibold text-lg">{t("secureVault")}</div>
            <div className="text-xs text-muted-foreground">Set a PIN to protect your sensitive files</div>
          </div>
        </div>
        <div className="space-y-3">
          <div className="relative">
            <Input
              type={showPin ? "text" : "password"}
              placeholder="Enter PIN (min 4 digits)"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSetPin()}
              className="pr-10"
            />
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground"
              onClick={() => setShowPin(!showPin)}
            >
              {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          {error && <div className="text-xs text-destructive">{error}</div>}
          <Button className="w-full" onClick={handleSetPin}>
            <Lock className="h-4 w-4 mr-2" /> Set PIN & Create Vault
          </Button>
        </div>
      </div>
    );
  }

  if (!unlocked) {
    return (
      <div className="flex flex-col h-full p-6 gap-4">
        <div className="flex flex-col items-center text-center gap-3 pb-4 border-b">
          <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center text-white shadow-lg">
            <Lock className="h-8 w-8" />
          </div>
          <div>
            <div className="font-semibold text-lg">{t("secureVault")}</div>
            <div className="text-xs text-muted-foreground">Enter your PIN to unlock</div>
          </div>
        </div>
        <div className="space-y-3">
          <div className="relative">
            <Input
              type={showPin ? "text" : "password"}
              placeholder="Enter PIN"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleUnlock()}
              className="pr-10"
              autoFocus
            />
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground"
              onClick={() => setShowPin(!showPin)}
            >
              {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          {error && <div className="text-xs text-destructive">{error}</div>}
          <Button className="w-full" onClick={handleUnlock}>
            <Unlock className="h-4 w-4 mr-2" /> Unlock
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="p-4 border-b">
        <div className="flex items-center gap-2 mb-3">
          <Unlock className="h-5 w-5 text-emerald-500" />
          <h2 className="font-semibold flex-1">{t("secureVault")}</h2>
          <Button variant="ghost" size="sm" onClick={() => setUnlocked(false)}>
            <Lock className="h-4 w-4" />
          </Button>
        </div>
        {/* Add new entry */}
        <div className="space-y-2 p-3 rounded-lg border bg-muted/30">
          <Input
            placeholder="Entry name"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            className="h-8 text-sm"
          />
          <textarea
            placeholder="Secret content (password, notes, etc.)"
            value={newContent}
            onChange={(e) => setNewContent(e.target.value)}
            className="w-full min-h-[60px] p-2 text-sm rounded border bg-background"
          />
          <Button size="sm" className="w-full" onClick={handleAdd} disabled={!newName || !newContent}>
            <Plus className="h-4 w-4 mr-1" /> Add Entry
          </Button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-3">
        {entries.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-2">
            <Shield className="h-12 w-12 opacity-30" />
            <div className="text-sm">No entries yet</div>
          </div>
        ) : (
          <div className="space-y-2">
            {entries.map(entry => (
              <div key={entry.id} className="flex items-center gap-2 p-2 rounded border hover:bg-accent">
                <Lock className="h-4 w-4 text-orange-500 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{entry.name}</div>
                  <div className="text-[10px] text-muted-foreground">{entry.size} bytes · encrypted</div>
                </div>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleDecrypt(entry)}>
                  <Eye className="h-3.5 w-3.5" />
                </Button>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => handleRemove(entry.id)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
