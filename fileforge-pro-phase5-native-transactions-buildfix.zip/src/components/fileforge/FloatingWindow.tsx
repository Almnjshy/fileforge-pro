// FileForge Pro — Floating window + Window Manager (Mobile-responsive)
"use client";

import React, { useRef, useState, useEffect } from "react";
import {
  X, Minus, Square, Copy, GripVertical, Layers, Columns2, ChevronLeft, ChevronRight, Eye, Info,
} from "lucide-react";
import { useFileForge } from "@/store/fileforge-store";
import type { FloatingWindow as FW } from "@/lib/fileforge/types";
import { cn } from "@/lib/utils";
import { TextEditor } from "./TextEditor";
import { LargeTextEditor } from "./LargeTextEditor";
import { FilePreview } from "./FilePreview";
import { PdfViewer } from "./PdfViewer";
import { PropertiesPanel } from "./PropertiesPanel";
import { ArchiveBrowser } from "./ArchiveBrowser";
import { SearchPanel } from "./SearchPanel";
import { StorageAnalyzer } from "./StorageAnalyzer";
import { SettingsPanel } from "./SettingsPanel";
import { SecureVaultPanel } from "./SecureVaultPanel";
import { CustomizationPanel } from "./CustomizationPanel";
import { WebViewer } from "./WebViewer";
import { HexViewer } from "./HexViewer";
import { FileBrowser } from "./FileBrowser";
import { getNode, getPathSegments } from "@/lib/fileforge/filesystem";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n/i18n-store";
import type { ReactNode } from "react";

class WindowErrorBoundary extends React.Component<{ children: ReactNode }, { hasError: boolean; message: string }> {
  state = { hasError: false, message: "" };
  static getDerivedStateFromError(error: unknown) {
    return { hasError: true, message: error instanceof Error ? error.message : "Window content failed" };
  }
  componentDidCatch(error: unknown) {
    console.error("FileForge floating window failed", error);
  }
  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div className="flex h-full w-full items-center justify-center p-6 text-center">
        <div className="max-w-md space-y-2">
          <div className="font-medium">تعذر عرض محتوى هذه النافذة</div>
          <div className="text-xs text-muted-foreground break-words">{this.state.message}</div>
          <div className="text-xs text-muted-foreground">يمكن إغلاق النافذة وإعادة فتح الملف دون تجميد بقية التطبيق.</div>
        </div>
      </div>
    );
  }
}


// Hook to detect mobile/tablet
function useViewport() {
  const [isMobile, setIsMobile] = useState(false);
  const [isTablet, setIsTablet] = useState(false);
  useEffect(() => {
    const check = () => {
      setIsMobile(window.innerWidth < 768);
      setIsTablet(window.innerWidth >= 768 && window.innerWidth < 1280);
    };
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);
  return { isMobile, isTablet };
}

export function FloatingWindow({ win }: { win: FW }) {
  const store = useFileForge();
  const { t, lang } = useI18n();
  const { isMobile, isTablet } = useViewport();
  const winRef = useRef<HTMLDivElement>(null);
  type DragType = "move" | "resize-se" | "resize-sw" | "resize-ne" | "resize-nw" | "resize-e" | "resize-w" | "resize-n" | "resize-s";
  const dragState = useRef<{
    type: DragType;
    startX: number; startY: number;
    origX: number; origY: number; origW: number; origH: number;
  } | null>(null);

  const isActive = store.activeWindowId === win.id;
  // On mobile, always treat as maximized (full-screen)
  const effectiveMaximized = win.maximized || isMobile;

  const onMouseDown = (e: React.MouseEvent, type: DragType) => {
    if (effectiveMaximized) return;
    e.stopPropagation();
    e.preventDefault();
    store.focusWindow(win.id);
    dragState.current = {
      type,
      startX: e.clientX, startY: e.clientY,
      origX: win.x, origY: win.y, origW: win.width, origH: win.height,
    };
    const handleMove = (ev: MouseEvent) => {
      const ds = dragState.current;
      if (!ds) return;
      const dx = ev.clientX - ds.startX;
      const dy = ev.clientY - ds.startY;
      const MIN_W = 280, MIN_H = 200;
      let { origX: nx, origY: ny, origW: nw, origH: nh } = ds;
      switch (ds.type) {
        case "move":
          nx = ds.origX + dx;
          ny = ds.origY + dy;
          nx = Math.max(-nw + 100, Math.min(window.innerWidth - 100, nx));
          ny = Math.max(0, Math.min(window.innerHeight - 40, ny));
          break;
        case "resize-se":
          nw = Math.max(MIN_W, ds.origW + dx);
          nh = Math.max(MIN_H, ds.origH + dy);
          break;
        case "resize-sw":
          nw = Math.max(MIN_W, ds.origW - dx);
          nh = Math.max(MIN_H, ds.origH + dy);
          nx = ds.origX + (ds.origW - nw);
          break;
        case "resize-ne":
          nw = Math.max(MIN_W, ds.origW + dx);
          nh = Math.max(MIN_H, ds.origH - dy);
          ny = ds.origY + (ds.origH - nh);
          break;
        case "resize-nw":
          nw = Math.max(MIN_W, ds.origW - dx);
          nh = Math.max(MIN_H, ds.origH - dy);
          nx = ds.origX + (ds.origW - nw);
          ny = ds.origY + (ds.origH - nh);
          break;
        case "resize-e":
          nw = Math.max(MIN_W, ds.origW + dx);
          break;
        case "resize-w":
          nw = Math.max(MIN_W, ds.origW - dx);
          nx = ds.origX + (ds.origW - nw);
          break;
        case "resize-s":
          nh = Math.max(MIN_H, ds.origH + dy);
          break;
        case "resize-n":
          nh = Math.max(MIN_H, ds.origH - dy);
          ny = ds.origY + (ds.origH - nh);
          break;
      }
      store.resizeWindow(win.id, nw, nh, nx, ny);
    };
    const handleUp = () => {
      dragState.current = null;
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mouseup", handleUp);
    };
    window.addEventListener("mousemove", handleMove);
    window.addEventListener("mouseup", handleUp);
  };

  // Touch support for mobile
  const onTouchStart = (e: React.TouchEvent, type: DragType) => {
    if (effectiveMaximized) return;
    e.stopPropagation();
    const tch = e.touches[0];
    store.focusWindow(win.id);
    dragState.current = {
      type,
      startX: tch.clientX, startY: tch.clientY,
      origX: win.x, origY: win.y, origW: win.width, origH: win.height,
    };
    const handleMove = (ev: TouchEvent) => {
      const ds = dragState.current;
      if (!ds) return;
      const t2 = ev.touches[0];
      const dx = t2.clientX - ds.startX;
      const dy = t2.clientY - ds.startY;
      if (ds.type === "move") {
        let nx = Math.max(-win.width + 100, Math.min(window.innerWidth - 100, ds.origX + dx));
        let ny = Math.max(0, Math.min(window.innerHeight - 40, ds.origY + dy));
        store.moveWindow(win.id, nx, ny);
      }
    };
    const handleEnd = () => {
      dragState.current = null;
      window.removeEventListener("touchmove", handleMove);
      window.removeEventListener("touchend", handleEnd);
    };
    window.addEventListener("touchmove", handleMove, { passive: false });
    window.addEventListener("touchend", handleEnd);
  };

  // When minimized, hide the window via CSS (display:none) instead of
  // returning null. This preserves the subtree's internal state (scroll
  // position, form inputs, etc.) so restore brings back the exact view.
  // HOWEVER, for heavy media windows (video/audio/pdf), we DON'T render
  // the content when minimized — those hold Blob URLs and media elements
  // that consume significant RAM. They'll re-init on restore.
  const isHeavyMedia = win.type === "video-preview" || win.type === "audio-preview" || win.type === "pdf-preview" || win.type === "web-preview" || win.type === "hex-preview" || win.type === "archive-preview";

  if (win.minimized) {
    // For light windows (folder, text, archive, properties), keep the subtree
    // alive so scroll position and form inputs are preserved on restore.
    if (!isHeavyMedia) {
      return (
        <div style={{ display: "none", position: "absolute", width: 0, height: 0, overflow: "hidden", pointerEvents: "none" }}>
          <WindowErrorBoundary><WindowContent win={win} /></WindowErrorBoundary>
        </div>
      );
    }
    // For heavy media windows, render a lightweight placeholder.
    // The actual media element will re-initialize when the window is restored.
    return null;
  }

  // Mobile: floating mini-windows (not bottom-sheet).
  // Each window is a small floating card that can be moved, resized, minimized.
  // Multiple windows can be visible simultaneously — the user taps one to focus.
  // This is a real multi-window experience, not a modal sheet.
  if (isMobile) {
    // Use a smaller default size on mobile so multiple windows fit
    const mobileWidth = Math.min(win.width, window.innerWidth - 32);
    const mobileHeight = Math.min(win.height, window.innerHeight * 0.6);
    const mobileX = Math.min(win.x, window.innerWidth - mobileWidth - 16);
    const mobileY = Math.min(win.y, window.innerHeight - mobileHeight - 16);
    return (
      <div
        ref={winRef}
        className={cn(
          "fixed flex flex-col bg-background rounded-lg shadow-2xl border overflow-hidden pointer-events-auto",
          isActive ? "border-orange-500/60 ring-2 ring-orange-500/20" : "border-border",
        )}
        style={{
          zIndex: win.zIndex,
          left: mobileX,
          top: mobileY,
          width: mobileWidth,
          height: mobileHeight,
        }}
        onTouchStart={(e) => onTouchStart(e, "move")}
        onMouseDown={() => { if (!isActive) store.focusWindow(win.id); }}
      >
        {/* Mobile title bar — compact */}
        <div
          className="flex items-center gap-1 px-2 h-9 border-b bg-muted/40 flex-shrink-0 cursor-move touch-none select-none"
          onMouseDown={(e) => onMouseDown(e, "move")}
        >
          <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0"
            onClick={(e) => { e.stopPropagation(); store.closeWindow(win.id); }}
            aria-label={t("close")}
          >
            <X className="h-3.5 w-3.5" />
          </Button>
          <span className="text-xs font-medium truncate flex-1">{win.title}</span>
          <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0"
            onClick={(e) => { e.stopPropagation(); store.minimizeWindow(win.id); }}
            aria-label={t("minimize")}
          >
            <Minus className="h-3.5 w-3.5" />
          </Button>
        </div>
        <div className="flex-1 min-h-0 overflow-hidden bg-background">
          <WindowErrorBoundary><WindowContent win={win} /></WindowErrorBoundary>
        </div>
      </div>
    );
  }

  // Desktop/Tablet: floating window with full controls
  const style: React.CSSProperties = effectiveMaximized
    ? { left: 0, top: 0, width: "100%", height: "100%", zIndex: win.zIndex }
    : { left: win.x, top: win.y, width: win.width, height: win.height, zIndex: win.zIndex };

  return (
    <div
      ref={winRef}
      className={cn(
        "absolute flex flex-col bg-background border shadow-2xl rounded-lg overflow-hidden pointer-events-auto",
        isActive ? "border-orange-500/60 ring-1 ring-orange-500/30 shadow-orange-500/10" : "border-border"
      )}
      style={style}
      onMouseDown={() => { if (!isActive) store.focusWindow(win.id); }}
    >
      {/* Title bar */}
      <div
        className="flex items-center gap-1 px-2 h-9 border-b bg-muted/40 cursor-move flex-shrink-0 select-none touch-none"
        onMouseDown={(e) => onMouseDown(e, "move")}
        onTouchStart={(e) => onTouchStart(e, "move")}
        onDoubleClick={() => store.toggleMaximizeWindow(win.id)}
      >
        <GripVertical className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
        <span className="text-xs font-medium truncate flex-1">{win.title}</span>
        <Button
          variant="ghost" size="icon" className="h-6 w-6"
          onClick={(e) => { e.stopPropagation(); store.minimizeWindow(win.id); }}
          aria-label={t("minimize")}
        >
          <Minus className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="ghost" size="icon" className="h-6 w-6"
          onClick={(e) => { e.stopPropagation(); store.toggleMaximizeWindow(win.id); }}
          aria-label={t("maximize")}
        >
          <Square className="h-3 w-3" />
        </Button>
        <Button
          variant="ghost" size="icon" className="h-6 w-6 hover:bg-destructive hover:text-destructive-foreground"
          onClick={(e) => { e.stopPropagation(); store.closeWindow(win.id); }}
          aria-label={t("close")}
        >
          <X className="h-3.5 w-3.5" />
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 min-h-0 overflow-hidden bg-background">
        <WindowErrorBoundary><WindowContent win={win} /></WindowErrorBoundary>
      </div>

      {/* Resize handles — desktop only */}
      {!effectiveMaximized && (
        <>
          <div className="absolute top-0 left-0 w-3 h-3 cursor-nw-resize" aria-label="Resize" onMouseDown={(e) => onMouseDown(e, "resize-nw")} />
          <div className="absolute top-0 right-0 w-3 h-3 cursor-ne-resize" aria-label="Resize" onMouseDown={(e) => onMouseDown(e, "resize-ne")} />
          <div className="absolute bottom-0 left-0 w-3 h-3 cursor-sw-resize" aria-label="Resize" onMouseDown={(e) => onMouseDown(e, "resize-sw")} />
          <div className="absolute bottom-0 right-0 w-3 h-3 cursor-se-resize" aria-label="Resize" onMouseDown={(e) => onMouseDown(e, "resize-se")} />
          <div className="absolute top-0 left-3 right-3 h-1 cursor-n-resize" aria-label="Resize" onMouseDown={(e) => onMouseDown(e, "resize-n")} />
          <div className="absolute bottom-0 left-3 right-3 h-1 cursor-s-resize" aria-label="Resize" onMouseDown={(e) => onMouseDown(e, "resize-s")} />
          <div className="absolute left-0 top-3 bottom-3 w-1 cursor-w-resize" aria-label="Resize" onMouseDown={(e) => onMouseDown(e, "resize-w")} />
          <div className="absolute right-0 top-3 bottom-3 w-1 cursor-e-resize" aria-label="Resize" onMouseDown={(e) => onMouseDown(e, "resize-e")} />
        </>
      )}
    </div>
  );
}

function WindowContent({ win }: { win: FW }) {
  if (win.type === "folder" && win.path) {
    return <FolderWindowContent win={win} />;
  }
  if (win.type === "text-editor" && win.nodeId) {
    const node = getNode(win.nodeId);
    if (node?.size != null && node.size > 5_000_000) {
      return <LargeTextEditor nodeId={win.nodeId} winId={win.id} />;
    }
    return <TextEditor nodeId={win.nodeId} winId={win.id} />;
  }
  if (win.type === "image-preview" && win.nodeId) {
    return <FilePreview nodeId={win.nodeId} kind="image" windowId={win.id} windowGeometry={win} />;
  }
  if (win.type === "video-preview" && win.nodeId) {
    return <FilePreview nodeId={win.nodeId} kind="video" windowId={win.id} windowGeometry={win} />;
  }
  if (win.type === "audio-preview" && win.nodeId) {
    return <FilePreview nodeId={win.nodeId} kind="audio" windowId={win.id} windowGeometry={win} />;
  }
  if (win.type === "pdf-preview" && win.nodeId) {
    return <PdfViewer nodeId={win.nodeId} fileName={win.title} />;
  }
  if (win.type === "archive-preview" && win.nodeId) {
    return <ArchiveBrowser nodeId={win.nodeId} />;
  }
  if (win.type === "web-preview" && win.nodeId) {
    return <WebViewer nodeId={win.nodeId} fileName={win.title} />;
  }
  if (win.type === "hex-preview" && win.nodeId) {
    return <HexViewer nodeId={win.nodeId} fileName={win.title} />;
  }
  if (win.type === "properties" && win.nodeId) {
    return <PropertiesPanel nodeId={win.nodeId} />;
  }
  if (win.type === "search") {
    return <SearchPanel />;
  }
  if (win.type === "storage-analyzer") {
    return <StorageAnalyzer />;
  }
  if (win.type === "settings") {
    // Render different panels based on title
    if (win.title.includes("Vault") || win.title.includes("خزنة") || win.title.includes("الخزنة")) {
      return <SecureVaultPanel />;
    }
    if (win.title === "Customization") {
      return <CustomizationPanel />;
    }
    return <SettingsPanel />;
  }
  return <div className="p-4 text-sm text-muted-foreground">Unknown window type</div>;
}

function FolderWindowContent({ win }: { win: FW }) {
  const store = useFileForge();
  const path = win.path!;
  const segments = getPathSegments(path);
  const node = getNode(path);

  const canBack = store.canGoBackInWindow(win.id);
  const canForward = store.canGoForwardInWindow(win.id);

  return (
    <div className="flex flex-col h-full">
      {/* Mini toolbar with working navigation: Back / Forward / Up + breadcrumbs */}
      <div className="flex items-center gap-1 px-2 h-8 border-b bg-muted/20 flex-shrink-0">
        <Button
          variant="ghost" size="icon" className="h-6 w-6"
          disabled={!canBack}
          onClick={() => store.goBackInWindow(win.id)}
          aria-label="Back"
        >
          <ChevronLeft className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="ghost" size="icon" className="h-6 w-6"
          disabled={!canForward}
          onClick={() => store.goForwardInWindow(win.id)}
          aria-label="Forward"
        >
          <ChevronRight className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="ghost" size="icon" className="h-6 w-6"
          disabled={!node?.parentId}
          onClick={() => {
            if (node?.parentId) {
              store.navigateInWindow(win.id, node.parentId!);
            }
          }}
          aria-label="Up"
        >
          <span className="text-xs">↑</span>
        </Button>
        <div className="flex-1 overflow-x-auto scrollbar-thin">
          <div className="flex items-center text-[11px] whitespace-nowrap px-1">
            {segments.map((s, i) => (
              <span key={s.path} className="flex items-center">
                <button
                  className={cn("px-1.5 py-0.5 rounded hover:bg-accent", i === segments.length - 1 && "font-medium")}
                  onClick={() => {
                    store.navigateInWindow(win.id, s.path);
                  }}
                >
                  {s.name}
                </button>
                {i < segments.length - 1 && <span className="text-muted-foreground">/</span>}
              </span>
            ))}
          </div>
        </div>
      </div>
      <FileBrowser path={path} paneId="dual" embeddedInWindow windowId={win.id} />
    </div>
  );
}

// ============ Window Manager Bar (Professional Dock) ============
export function WindowManagerBar() {
  const store = useFileForge();
  const { t, lang } = useI18n();
  const [open, setOpen] = useState(false);
  const { isMobile } = useViewport();

  // Count minimized windows
  const minimizedCount = store.windows.filter(w => w.minimized).length;
  const totalCount = store.windows.length;
  if (totalCount === 0) return null;

  return (
    <>
      {/* Dock button - always visible when windows exist */}
      <div className={cn(
        "fixed z-[200] flex items-center gap-1",
        isMobile ? "bottom-4 right-4" : "bottom-4 right-4"
      )}>
        {/* Quick restore minimized windows (chips) */}
        {minimizedCount > 0 && !open && (
          <div className="flex items-center gap-1 mr-1">
            {store.windows.filter(w => w.minimized).slice(0, 3).map(w => (
              <button
                key={w.id}
                onClick={() => store.focusWindow(w.id)}
                className="h-9 px-2 rounded-lg bg-popover border shadow-md flex items-center gap-1.5 hover:bg-accent transition-colors max-w-[120px]"
                title={w.title}
              >
                {w.type === "folder" ? <Columns2 className="h-3.5 w-3.5 flex-shrink-0" /> :
                 w.type === "text-editor" ? <Copy className="h-3.5 w-3.5 flex-shrink-0" /> :
                 <Layers className="h-3.5 w-3.5 flex-shrink-0" />}
                <span className="text-xs truncate">{w.title}</span>
              </button>
            ))}
            {minimizedCount > 3 && (
              <button
                onClick={() => setOpen(true)}
                className="h-9 px-2 rounded-lg bg-popover border shadow-md flex items-center text-xs hover:bg-accent"
              >
                +{minimizedCount - 3}
              </button>
            )}
          </div>
        )}

        {/* Main dock button */}
        <Button
          variant="secondary"
          size="sm"
          className={cn(
            "shadow-lg gap-2 h-10 px-3",
            open && "ring-2 ring-orange-500/50"
          )}
          onClick={() => setOpen(!open)}
        >
          <Layers className="h-4 w-4" />
          <span className="font-bold text-orange-500">{totalCount}</span>
          {!isMobile && <span className="text-muted-foreground text-xs">{t("windowsCount")}</span>}
        </Button>
      </div>

      {/* Dock panel (expandable) */}
      {open && (
        <>
          <div className="fixed inset-0 z-[150]" onClick={() => setOpen(false)} />
          <div className={cn(
            "fixed z-[200] rounded-xl border bg-popover shadow-2xl overflow-hidden animate-in slide-in-from-bottom-2",
            isMobile ? "bottom-20 right-4 left-4 max-h-[60vh]" : "bottom-20 right-4 w-80 max-h-[70vh]"
          )}>
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b bg-muted/30">
              <div className="flex items-center gap-2">
                <Layers className="h-4 w-4 text-orange-500" />
                <span className="text-sm font-semibold">{t("openWindows")}</span>
                <span className="text-xs text-muted-foreground">({totalCount})</span>
              </div>
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost" size="sm" className="h-7 text-xs"
                  onClick={() => {
                    // Restore all minimized
                    store.windows.filter(w => w.minimized).forEach(w => store.focusWindow(w.id));
                  }}
                >
                  {lang === "ar" ? "استعادة الكل" : "Restore All"}
                </Button>
                <Button
                  variant="ghost" size="sm" className="h-7 text-xs text-destructive hover:text-destructive"
                  onClick={() => store.closeAllWindows()}
                >
                  {t("closeAll")}
                </Button>
              </div>
            </div>

            {/* Window list */}
            <div className="max-h-[50vh] overflow-y-auto p-2 space-y-1">
              {store.windows.map(w => (
                <div
                  key={w.id}
                  className={cn(
                    "flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-colors group",
                    w.minimized
                      ? "bg-muted/40 hover:bg-accent opacity-70"
                      : store.activeWindowId === w.id
                      ? "bg-orange-500/10 ring-1 ring-orange-500/30"
                      : "hover:bg-accent"
                  )}
                  onClick={() => {
                    store.focusWindow(w.id);
                    setOpen(false);
                  }}
                >
                  {/* Icon */}
                  <div className={cn(
                    "h-8 w-8 flex items-center justify-center rounded-lg flex-shrink-0",
                    w.minimized ? "bg-muted" : "bg-primary/10"
                  )}>
                    {w.type === "folder" ? <Columns2 className="h-4 w-4" /> :
                     w.type === "text-editor" ? <Copy className="h-4 w-4" /> :
                     w.type === "image-preview" ? <Eye className="h-4 w-4" /> :
                     w.type === "properties" ? <Info className="h-4 w-4" /> :
                     <Layers className="h-4 w-4" />}
                  </div>

                  {/* Title + status */}
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{w.title}</div>
                    <div className="text-[10px] text-muted-foreground flex items-center gap-1">
                      {w.minimized && (
                        <span className="text-orange-500">● {t("minimize")}</span>
                      )}
                      {!w.minimized && store.activeWindowId === w.id && (
                        <span className="text-emerald-500">● Active</span>
                      )}
                      <span className="capitalize">{w.type.replace("-", " ")}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    {!w.minimized ? (
                      <Button
                        variant="ghost" size="icon" className="h-7 w-7"
                        onClick={(e) => { e.stopPropagation(); store.minimizeWindow(w.id); }}
                        title={t("minimize")}
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </Button>
                    ) : (
                      <Button
                        variant="ghost" size="icon" className="h-7 w-7"
                        onClick={(e) => { e.stopPropagation(); store.focusWindow(w.id); }}
                        title="Restore"
                      >
                        <Square className="h-3 w-3" />
                      </Button>
                    )}
                    <Button
                      variant="ghost" size="icon" className="h-7 w-7 hover:bg-destructive hover:text-destructive-foreground"
                      onClick={(e) => { e.stopPropagation(); store.closeWindow(w.id); }}
                      title={t("close")}
                    >
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="px-4 py-2 border-t bg-muted/20 text-xs text-muted-foreground flex justify-between">
              <span>{minimizedCount} {t("minimize")}</span>
              <span>{totalCount - minimizedCount} Active</span>
            </div>
          </div>
        </>
      )}
    </>
  );
}
