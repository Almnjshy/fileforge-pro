// FileForge Pro — Large Document Engine
// Paged/chunked text model for files too large to materialize as one JS string.
// The engine keeps only a small working set in memory and delegates I/O to Native.

import { nativeFileSystem } from "./native-bridge";

export const LARGE_DOCUMENT_PAGE_BYTES = 256 * 1024;
export const LARGE_DOCUMENT_MAX_CACHED_PAGES = 4;

type Page = { index: number; offset: number; bytes: number; text: string; dirty: boolean };

function base64ToBytes(b64: string): Uint8Array {
  if (typeof atob === "function") {
    const raw = atob(b64); const out = new Uint8Array(raw.length);
    for (let i=0;i<raw.length;i++) out[i]=raw.charCodeAt(i); return out;
  }
  return new Uint8Array();
}

function bytesToBase64(bytes: Uint8Array): string {
  let s=""; const step=0x8000;
  for(let i=0;i<bytes.length;i+=step) s += String.fromCharCode(...bytes.subarray(i,i+step));
  return btoa(s);
}

export class LargeDocumentEngine {
  readonly path: string;
  private _fileSize: number;
  private pages = new Map<number, Page>();
  private decoder = new TextDecoder("utf-8", { fatal: false });
  private encoder = new TextEncoder();
  private _dirty = false;

  constructor(path: string, fileSize: number) { this.path=path; this._fileSize=fileSize; }
  get fileSize(){ return this._fileSize; }
  get dirty(){ return this._dirty; }
  get pageCount(){ return Math.max(1, Math.ceil(this.fileSize / LARGE_DOCUMENT_PAGE_BYTES)); }

  async loadPage(index: number): Promise<Page> {
    if (index < 0 || index >= this.pageCount) throw new RangeError("Page out of range");
    const cached=this.pages.get(index); if(cached) return cached;
    const offset=index*LARGE_DOCUMENT_PAGE_BYTES;
    const length=Math.min(LARGE_DOCUMENT_PAGE_BYTES, Math.max(0,this.fileSize-offset));
    const chunk=await nativeFileSystem.readFileChunk(this.path, offset, length);
    if(!chunk) throw new Error("Unable to read document chunk");
    const bytes=base64ToBytes(chunk.content);
    // UTF-8 is decoded per page. We keep the raw bytes for untouched pages, so page-boundary
    // characters are never rewritten unless that page is explicitly edited. If a boundary
    // produces U+FFFD, the UI can warn before saving that page.
    const text=this.decoder.decode(bytes,{stream:false});
    const page:Page={index,offset,bytes:bytes.length,text,dirty:false};
    this.pages.set(index,page); this.evict(); return page;
  }

  async updatePage(index:number,text:string):Promise<void>{
    const page=await this.loadPage(index); page.text=text; page.dirty=true; this._dirty=true;
  }

  /** Return a small editable page rather than the entire document. */
  async getPageText(index:number):Promise<string>{ return (await this.loadPage(index)).text; }

  /** Save using sequential native chunk writes. Edited pages are encoded; untouched pages are re-read. */
  async save(onProgress?: (fraction:number)=>void):Promise<void>{
    // For a paged editor, edits change byte lengths. Rebuilding sequentially is deliberate.
    // It keeps the entire document out of JS memory while preserving all untouched pages.
    const pageCount=this.pageCount; let outOffset=0;
    const tempRef=await nativeFileSystem.beginLargeWrite(this.path);
    if(!tempRef) throw new Error("Native large-write session unavailable");
    try {
    for(let i=0;i<pageCount;i++){
      const page=this.pages.get(i);
      let bytes:Uint8Array;
      if(page?.dirty){ bytes=this.encoder.encode(page.text); }
      else {
        const offset=i*LARGE_DOCUMENT_PAGE_BYTES;
        const length=Math.min(LARGE_DOCUMENT_PAGE_BYTES,Math.max(0,this.fileSize-offset));
        const chunk=await nativeFileSystem.readFileChunk(this.path,offset,length);
        if(!chunk) throw new Error(`Unable to reread page ${i}`);
        bytes=base64ToBytes(chunk.content);
      }
      // If an earlier edit changed length, untouched source pages are still read from their original offsets.
      // This is safe because output is sequential and source reads use original offsets.
      const b64=bytesToBase64(bytes);
      const ok=await nativeFileSystem.writeFileChunk(tempRef,outOffset,b64,i===0);
      if(!ok) throw new Error(`Unable to write page ${i}`);
      outOffset += bytes.length;
      onProgress?.((i+1)/pageCount);
    }
    const committed=await nativeFileSystem.commitLargeWrite(this.path,tempRef);
    if(!committed) throw new Error("Unable to commit large document");
    this._fileSize=outOffset;
    this.pages.clear();
    this._dirty=false;
    } catch(e) {
      await nativeFileSystem.abortLargeWrite(tempRef);
      throw e;
    }
  }

  unloadPage(index:number){ if(this.pages.get(index)?.dirty) return; this.pages.delete(index); }
  clearCache(){ for(const [i,p] of this.pages) if(!p.dirty) this.pages.delete(i); }
  private evict(){
    if(this.pages.size<=LARGE_DOCUMENT_MAX_CACHED_PAGES)return;
    for(const [i,p] of this.pages){ if(!p.dirty){this.pages.delete(i); if(this.pages.size<=LARGE_DOCUMENT_MAX_CACHED_PAGES)break;} }
  }
}
