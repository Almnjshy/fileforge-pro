// FileForge Pro — Window State Persistence
// Saves floating window state to localStorage so it survives process death.
// On app restart, windows are restored with their paths, geometry, and types.

"use client";

import type { FloatingWindow, FloatingWindowType } from "./types";

const STORAGE_KEY = "fileforge-window-state-v2";
const LEGACY_STORAGE_KEY = "fileforge-window-state-v1";

interface PersistedWindowState {
  id: string;
  type: FloatingWindowType;
  title: string;
  path?: string;
  nodeId?: string;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  minimized: boolean;
  maximized: boolean;
}

export function saveWindowState(windows: FloatingWindow[]): void {
  if (typeof window === "undefined") return;
  try {
    const persisted: PersistedWindowState[] = windows.map(w => ({
      id: w.id,
      type: w.type,
      title: w.title,
      path: w.path,
      nodeId: w.nodeId,
      x: w.x,
      y: w.y,
      width: w.width,
      height: w.height,
      zIndex: w.zIndex,
      minimized: false, // Never restore as minimized — user should see it
      maximized: w.maximized,
    }));
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ version: 2, savedAt: Date.now(), windows: persisted }));
  } catch {
    // Quota exceeded — ignore
  }
}

export function loadWindowState(): PersistedWindowState[] {
  if (typeof window === "undefined") return [];
  try {
    let raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) raw = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    const windows = Array.isArray(parsed) ? parsed : parsed?.windows;
    if (!Array.isArray(windows)) return [];
    return windows.filter(w =>
      typeof w.id === "string" &&
      typeof w.type === "string" &&
      typeof w.title === "string"
    );
  } catch {
    return [];
  }
}

export function clearWindowState(): void {
  if (typeof window === "undefined") return;
  try { localStorage.removeItem(STORAGE_KEY); localStorage.removeItem(LEGACY_STORAGE_KEY); } catch { /* ignore */ }
}
