// FileForge Pro — Thumbnail Manager
//
// Central thumbnail system used by ALL components:
//   FileBrowser (Grid/List/Details), SearchPanel, Sidebar recents,
//   FloatingWindow folder contents, ArchiveBrowser.
//
// Architecture:
//   UI → useThumbnail hook → ThumbnailManager → Native plugin (Kotlin)
//                                      ↓
//                              ThumbnailCache (memory LRU + IndexedDB)
//
// Cache key: `${path}:${lastModified}:${fileSize}`
//   — if the file changes, the key changes, a new thumbnail is generated.
//   — if the file hasn't changed, the cached thumbnail is returned instantly.
//
// Request deduplication: if two components ask for the same thumbnail at the
// same time, only one native call is made. Both get the same promise.
//
// All native calls run on background threads (Kotlin ioScope). The JS side
// is fully async — no synchronous disk I/O on the main thread.

"use client";

import { nativeFileSystem, isNative } from "./native-bridge";
import { getThumbnail as getWebThumbnail, setThumbnail as setWebThumbnail } from "./real-fs";
import { logger } from "./logger";

// ============ Types ============

export interface ThumbnailRequest {
  path: string;
  kind: string;      // "image" | "video" | other
  size?: number;     // max dimension in px, default 200
  lastModified?: number;
  fileSize?: number;
}

export interface ThumbnailResult {
  dataUrl: string | null;  // data:image/jpeg;base64,...  or null on failure
  loading: boolean;
  error: string | null;
}

// ============ Thumbnail Cache ============
// Memory LRU cache — max 200 entries (~200 × 8KB avg = ~1.6MB)

class MemoryCache {
  private map = new Map<string, string>();
  private maxEntries = 200;

  get(key: string): string | null {
    const val = this.map.get(key);
    if (val !== undefined) {
      // Move to end (most recently used)
      this.map.delete(key);
      this.map.set(key, val);
      return val;
    }
    return null;
  }

  set(key: string, value: string): void {
    if (this.map.has(key)) this.map.delete(key);
    this.map.set(key, value);
    // Evict oldest entries if over capacity
    while (this.map.size > this.maxEntries) {
      const oldest = this.map.keys().next().value;
      if (oldest === undefined) break;
      this.map.delete(oldest);
    }
  }

  invalidate(key: string): void {
    this.map.delete(key);
  }

  keys(): string[] {
    return Array.from(this.map.keys());
  }

  clear(): void {
    this.map.clear();
  }
}

// ============ Thumbnail Manager ============

class ThumbnailManager {
  private memCache = new MemoryCache();
  private pendingRequests = new Map<string, Promise<string | null>>();
  private failedRequests = new Set<string>(); // avoid retrying failed thumbs

  /**
   * Build a cache key from path + lastModified + fileSize.
   * If the file changes, the key changes → new thumbnail is generated.
   */
  private cacheKey(req: ThumbnailRequest): string {
    return `${req.path}:${req.lastModified ?? 0}:${req.fileSize ?? 0}`;
  }

  /**
   * Get a thumbnail for a file. Returns a data URL or null.
   * Checks memory cache → web sessionStorage → generates via native plugin.
   * Deduplicates concurrent requests for the same key.
   */
  async getThumbnail(req: ThumbnailRequest): Promise<string | null> {
    // Only generate for image/video
    if (req.kind !== "image" && req.kind !== "video") return null;

    const key = this.cacheKey(req);

    // 1. Check memory cache
    const cached = this.memCache.get(key);
    if (cached !== null) return cached;

    // 2. Check if this request is already in-flight (dedup)
    const pending = this.pendingRequests.get(key);
    if (pending) return pending;

    // 3. Check web thumbnail cache (sessionStorage, for uploaded files)
    if (!isNative()) {
      const webThumb = getWebThumbnail(req.path);
      if (webThumb && webThumb.startsWith("data:")) {
        this.memCache.set(key, webThumb);
        return webThumb;
      }
    }

    // 4. Don't retry previously failed requests (avoid spamming native calls)
    if (this.failedRequests.has(key)) return null;

    // 5. Start generation
    const promise = this.generateThumbnail(req, key);
    this.pendingRequests.set(key, promise);

    try {
      const result = await promise;
      if (result) {
        this.memCache.set(key, result);
        // Also persist to web cache for uploaded files
        if (!isNative() && req.path.startsWith("u-")) {
          setWebThumbnail(req.path, result);
        }
      } else {
        this.failedRequests.add(key);
      }
      return result;
    } finally {
      this.pendingRequests.delete(key);
    }
  }

  /**
   * Generate a thumbnail via the native plugin or web fallback.
   */
  private async generateThumbnail(req: ThumbnailRequest, _key: string): Promise<string | null> {
    try {
      if (isNative() && req.path.startsWith("/")) {
        // Native: call Kotlin generateThumbnail
        const maxSize = req.size ?? 200;
        const result = await nativeFileSystem.generateThumbnail(req.path, maxSize);
        if (result) {
          // The native plugin returns a raw base64 string (no data: prefix)
          return result.startsWith("data:") ? result : `data:image/jpeg;base64,${result}`;
        }
        return null;
      } else {
        // Web: generate from node content if available
        const { getNode } = await import("./filesystem");
        const node = getNode(req.path);
        if (node?.content?.startsWith("data:")) {
          // It's already a data URL — use as-is (could be the full image)
          // For uploaded files, a thumbnail was already generated in addUploadedFiles
          const webThumb = getWebThumbnail(req.path);
          return webThumb ?? null;
        }
        return null;
      }
    } catch (e) {
      logger.warn("thumbnail-manager", `Failed to generate thumbnail for ${req.path}`, e);
      return null;
    }
  }

  /**
   * Invalidate cache for a specific file (called after mutations).
   */
  invalidate(path: string): void {
    // Invalidate all keys that start with this path
    // (We don't know the exact lastModified/fileSize, so we clear all variants)
    // This is safe because the memory cache is small.
    for (const key of this.memCache.keys()) {
      if (key.startsWith(path + ":")) {
        this.memCache.invalidate(key);
        this.failedRequests.delete(key);
      }
    }
    for (const key of Array.from(this.failedRequests)) {
      if (key.startsWith(path + ":")) this.failedRequests.delete(key);
    }
  }

  /**
   * Clear all cached thumbnails.
   */
  clearAll(): void {
    this.memCache.clear();
    this.failedRequests.clear();
  }
}

// Singleton
export const thumbnailManager = new ThumbnailManager();
