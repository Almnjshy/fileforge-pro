// FileForge Pro — Unified Archive Provider
//
// Single API surface for all archive formats: ZIP, RAR, 7z, TAR, TAR.GZ,
// TGZ, GZ, BZ2, XZ. The ArchiveBrowser component talks only to this
// interface — it doesn't import JSZip or any other library directly.
//
// Routing:
//   - On native Android (Capacitor): routes through the Kotlin ArchiveEngine
//     via the FileForgeFileAccess plugin. Supports ZIP, RAR (3 & 5, password-
//     protected), 7z (password-protected), TAR, TAR.GZ, TGZ, GZ, BZ2, XZ.
//   - On web: ZIP is supported via JSZip (loaded dynamically). Other formats
//     return an honest "requires native Android app" error rather than
//     pretending to work.

"use client";

import { nativeFileSystem, isNative } from "./native-bridge";
import { getNode } from "./filesystem";
import { getThumbnail } from "./real-fs";

export interface ArchiveEntry {
  path: string;
  isDirectory: boolean;
  size: number;
  compressedSize: number;
  modified: number;
  isEncrypted: boolean;
}

export interface OpenArchiveResult {
  entries: ArchiveEntry[];
  isEncrypted: boolean;
  needsPassword: boolean;
  formatHint: string;
}

export interface ArchiveProvider {
  listEntries(nodeId: string, password?: string): Promise<OpenArchiveResult>;
  extractEntry(nodeId: string, entryPath: string, targetPath: string, password?: string): Promise<boolean>;
  extractAll(nodeId: string, targetDir: string, password?: string, operationId?: string): Promise<number>;
  readEntryBytes(nodeId: string, entryPath: string, password?: string): Promise<Uint8Array | null>;
}

// ============ Native Android provider ============
class NativeArchiveProvider implements ArchiveProvider {
  async listEntries(nodeId: string, password?: string): Promise<OpenArchiveResult> {
    const cap = (window as any).Capacitor;
    const plugin = cap?.Plugins?.FileForgeFileAccess;
    if (!plugin) throw new Error("Archive plugin not available");
    const result = await plugin.archiveList({ path: nodeId, password: password ?? "" });
    const entries: ArchiveEntry[] = (result.entries ?? []).map((e: any) => ({
      path: e.path,
      isDirectory: !!e.isDirectory,
      size: e.size ?? 0,
      compressedSize: e.compressedSize ?? 0,
      modified: e.modified ?? 0,
      isEncrypted: !!e.isEncrypted,
    }));
    return {
      entries,
      isEncrypted: !!result.isEncrypted,
      needsPassword: !!result.needsPassword,
      formatHint: result.format ?? "unknown",
    };
  }

  async extractEntry(nodeId: string, entryPath: string, targetPath: string, password?: string): Promise<boolean> {
    const cap = (window as any).Capacitor;
    const plugin = cap?.Plugins?.FileForgeFileAccess;
    if (!plugin) throw new Error("Archive plugin not available");
    const result = await plugin.archiveExtractEntry({
      path: nodeId, entryPath, targetPath, password: password ?? "",
    });
    return !!result?.success;
  }

  async extractAll(nodeId: string, targetDir: string, password?: string, operationId?: string): Promise<number> {
    const cap = (window as any).Capacitor;
    const plugin = cap?.Plugins?.FileForgeFileAccess;
    if (!plugin) throw new Error("Archive plugin not available");
    const result = await plugin.archiveExtractAll({
      path: nodeId, targetDir, password: password ?? "", operationId: operationId ?? "",
    });
    return result?.extracted ?? 0;
  }

  async readEntryBytes(nodeId: string, entryPath: string, password?: string): Promise<Uint8Array | null> {
    const cap = (window as any).Capacitor;
    const plugin = cap?.Plugins?.FileForgeFileAccess;
    if (!plugin) throw new Error("Archive plugin not available");
    try {
      const result = await plugin.archiveReadEntry({
        path: nodeId, entryPath, password: password ?? "",
      });
      if (!result?.content) return null;
      return base64ToUint8Array(result.content);
    } catch {
      return null;
    }
  }
}

// ============ Web provider (ZIP only via JSZip) ============
class WebArchiveProvider implements ArchiveProvider {
  private async loadArchiveBytes(nodeId: string): Promise<Uint8Array | null> {
    const node = getNode(nodeId);
    if (!node) return null;
    if (node.content) {
      if (node.content.startsWith("data:")) {
        try {
          const res = await fetch(node.content);
          return new Uint8Array(await res.arrayBuffer());
        } catch { return null; }
      }
    }
    const thumb = getThumbnail(nodeId);
    if (thumb && thumb.startsWith("data:")) {
      try {
        const res = await fetch(thumb);
        return new Uint8Array(await res.arrayBuffer());
      } catch { return null; }
    }
    return null;
  }

  async listEntries(nodeId: string, _password?: string): Promise<OpenArchiveResult> {
    const ext = nodeId.split(".").pop()?.toLowerCase() ?? "";
    if (ext !== "zip") {
      throw new Error(
        `On the web, only ZIP archives are supported. For ${ext.toUpperCase()} support, ` +
        `install the native Android APK.`
      );
    }
    const bytes = await this.loadArchiveBytes(nodeId);
    if (!bytes) throw new Error("Could not load archive bytes from in-memory storage.");
    const JSZip = (await import("jszip")).default;
    const zip = await JSZip.loadAsync(bytes);
    const entries: ArchiveEntry[] = [];
    await zip.forEach(async (path: string, file: any) => {
      entries.push({
        path,
        isDirectory: file.dir,
        size: file._data?.uncompressedSize ?? 0,
        compressedSize: file._data?.compressedSize ?? 0,
        modified: file.date ? file.date.getTime() : 0,
        isEncrypted: !!file.encrypted,
      });
    });
    await new Promise(r => setTimeout(r, 50));
    return {
      entries,
      isEncrypted: entries.some(e => e.isEncrypted),
      needsPassword: false,
      formatHint: "zip",
    };
  }

  async extractEntry(nodeId: string, entryPath: string, _targetPath: string, _password?: string): Promise<boolean> {
    // On web we can't write to disk; trigger a browser download instead.
    const bytes = await this.loadArchiveBytes(nodeId);
    if (!bytes) return false;
    const JSZip = (await import("jszip")).default;
    const zip = await JSZip.loadAsync(bytes);
    const file = zip.file(entryPath);
    if (!file) return false;
    const content = await file.async("uint8array");
    const blob = new Blob([content.buffer as ArrayBuffer]);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = entryPath.split("/").pop() ?? "extracted";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    return true;
  }

  async extractAll(nodeId: string, _targetDir: string, _password?: string, _operationId?: string): Promise<number> {
    // Web: trigger downloads for each entry.
    const bytes = await this.loadArchiveBytes(nodeId);
    if (!bytes) return 0;
    const JSZip = (await import("jszip")).default;
    const zip = await JSZip.loadAsync(bytes);
    let count = 0;
    const all = Object.values(zip.files) as any[];
    for (const file of all) {
      if (file.dir) continue;
      const content = await file.async("uint8array");
      const blob = new Blob([content.buffer as ArrayBuffer]);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = file.name.split("/").pop() ?? "extracted";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      count++;
      // Small delay to avoid overwhelming the browser
      await new Promise(r => setTimeout(r, 100));
    }
    return count;
  }

  async readEntryBytes(nodeId: string, entryPath: string, _password?: string): Promise<Uint8Array | null> {
    const bytes = await this.loadArchiveBytes(nodeId);
    if (!bytes) return null;
    const JSZip = (await import("jszip")).default;
    const zip = await JSZip.loadAsync(bytes);
    const file = zip.file(entryPath);
    if (!file) return null;
    return await file.async("uint8array");
  }
}

// Singleton accessors
const nativeProvider = new NativeArchiveProvider();
const webProvider = new WebArchiveProvider();

export function getArchiveProvider(): ArchiveProvider {
  return isNative() ? nativeProvider : webProvider;
}

// ============ Helpers ============
function base64ToUint8Array(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}
