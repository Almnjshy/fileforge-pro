// FileForge Pro — Centralized Back Handler
// Coordinates Android back button with app navigation state
// Priority: Dialog > Context Menu > Selection > Sidebar > Floating Window > Folder Navigation > Exit

"use client";

import { useEffect, useCallback, useRef } from "react";
import { useFileForge } from "@/store/fileforge-store";
import { logger } from "./logger";

// Global overlay counter — components increment this on mount and decrement on unmount.
// Replaces the fragile DOM-scraping approach that depended on Tailwind class names.
let overlayCount = 0;
const overlayListeners = new Set<() => void>();

export function registerOverlay(): () => void {
  overlayCount++;
  overlayListeners.forEach(l => l());
  return () => {
    overlayCount = Math.max(0, overlayCount - 1);
    overlayListeners.forEach(l => l());
  };
}

export function getOverlayCount(): number {
  return overlayCount;
}

export function subscribeOverlayCount(listener: () => void): () => void {
  overlayListeners.add(listener);
  return () => overlayListeners.delete(listener);
}

// Simulate the old "close top overlay" behavior by dispatching a custom event
// that overlays can listen for and close themselves.
function closeTopOverlay(): boolean {
  if (overlayCount > 0) {
    window.dispatchEvent(new CustomEvent("fileforge-close-overlay"));
    return true;
  }
  return false;
}

export function useBackHandler() {
  // Use individual selectors to avoid re-render storm
  const currentPath = useFileForge(s => s.currentPath);
  const historyIndex = useFileForge(s => s.historyIndex);
  const historyLen = useFileForge(s => s.history.length);
  const activeWindowId = useFileForge(s => s.activeWindowId);
  const windowsLen = useFileForge(s => s.windows.length);
  const selectedIdsSize = useFileForge(s => s.selectedIds.size);
  const sidebarOpen = useFileForge(s => s.sidebarOpen);
  const sidebarPinned = useFileForge(s => s.sidebarPinned);

  // Actions are stable references
  const clearSelection = useFileForge(s => s.clearSelection);
  const toggleSidebar = useFileForge(s => s.toggleSidebar);
  const closeWindow = useFileForge(s => s.closeWindow);
  const goBack = useFileForge(s => s.goBack);

  // Use a ref to hold the latest values so the back handler closure is stable
  const stateRef = useRef({
    currentPath, historyIndex, historyLen, activeWindowId, windowsLen,
    selectedIdsSize, sidebarOpen, sidebarPinned,
    clearSelection, toggleSidebar, closeWindow, goBack,
  });
  useEffect(() => {
    stateRef.current = {
      currentPath, historyIndex, historyLen, activeWindowId, windowsLen,
      selectedIdsSize, sidebarOpen, sidebarPinned,
      clearSelection, toggleSidebar, closeWindow, goBack,
    };
  });

  const handleBack = useCallback((): boolean => {
    const s = stateRef.current;
    logger.debug("back-handler", `back: path=${s.currentPath} hist=${s.historyIndex}/${s.historyLen - 1} win=${s.activeWindowId} sel=${s.selectedIdsSize} sidebar=${s.sidebarOpen} overlays=${overlayCount}`);

    // Priority 1: Close open dialogs/menus/popovers (registered via registerOverlay)
    if (closeTopOverlay()) return true;

    // Priority 2: Clear file selection
    if (s.selectedIdsSize > 0) {
      s.clearSelection();
      return true;
    }

    // Priority 3: Close sidebar if open (drawer mode)
    if (s.sidebarOpen && !s.sidebarPinned) {
      s.toggleSidebar();
      return true;
    }

    // Priority 4: Close active floating window
    if (s.windowsLen > 0 && s.activeWindowId) {
      s.closeWindow(s.activeWindowId);
      return true;
    }

    // Priority 5: Go back in folder navigation history
    if (s.historyIndex > 0) {
      s.goBack();
      return true;
    }

    // Priority 6: No internal back action - allow Android to exit
    return false;
  }, []);

  // Register global back handler ONCE (handleBack is stable thanks to ref)
  useEffect(() => {
    (window as any).__fileforgeBackButton = () => {
      const handled = handleBack();
      if (!handled) {
        try {
          const cap = (window as any).Capacitor;
          if (cap?.isNative && cap?.Plugins?.App) {
            cap.Plugins.App.exitApp();
          }
        } catch (e) {
          logger.error("back-handler", "Failed to exit app", e);
        }
      }
    };
    return () => {
      delete (window as any).__fileforgeBackButton;
    };
  }, [handleBack]);

  return { handleBack };
}
